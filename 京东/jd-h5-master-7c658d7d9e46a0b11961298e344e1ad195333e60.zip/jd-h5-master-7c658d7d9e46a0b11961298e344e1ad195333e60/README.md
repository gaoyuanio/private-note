# 京东商城

## 文件夹说明

./scripts: 原先写在html中的javascript
./styles: 原先写在html中的行内样式
./packages: 公共模块代码
./modules: 公共模块编译后的文件

其它文件夹为历史遗留文件