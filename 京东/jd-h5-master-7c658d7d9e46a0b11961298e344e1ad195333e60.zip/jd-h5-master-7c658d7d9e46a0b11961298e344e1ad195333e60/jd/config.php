<?php	
/* 参数设置 */
$app_key = '294aceb2178f476abac15dd66c1af36f';
$app_secret = 'af5f3f57179247f4be3fe110b0251070';
$redirect_uri = '';
$state = 1;
$view = 'wap';
$username = urlencode('汉得信息');
$password = md5('jd.com');
/* 引入JD类 */
?>